package smoove

const Version = "0.2.5"
